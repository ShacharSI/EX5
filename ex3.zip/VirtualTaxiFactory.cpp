//
// Created by haim on 11/27/16.
//

#include "VirtualTaxiFactory.h"

VirtualTaxiFactory::VirtualTaxiFactory(int taarif) {
    this->tarrif = taarif;
}

VirtualTaxiFactory::VirtualTaxiFactory() {

}