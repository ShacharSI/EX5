//
// Created by haim on 12/16/16.
//

#include "Validate_Interface.h"
